package TestCasesWeb;

import Actions.TestActions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HandleShadowDom extends TestActions {
    @BeforeMethod
    public void setUpHandleShadow(){
        commonSetUp("");
    }

    @Test
    public void testCaseShadowDom(){

    }
}
