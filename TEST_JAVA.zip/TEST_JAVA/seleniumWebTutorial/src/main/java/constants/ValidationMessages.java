package constants;

public class ValidationMessages {
    public static String Incorrect_Password = "The password you’ve entered is incorrect. Forgot Password?";
    public static String Incorrect_Login = "The email or mobile number you entered isn’t connected to an account. Find your account and log in.";
    public static String Reset_Password = "Forgot password?";
}
