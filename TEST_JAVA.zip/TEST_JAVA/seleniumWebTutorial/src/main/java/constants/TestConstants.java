package constants;

public class TestConstants extends TestUrls {
    public static String DEFAULT_LOGIN = "vassa306@gmail.com";
    public static String DEFAULT_PASS = "xxxxx";
    public static String LOGINPAGE_TITLE = "Facebook - log in or sign up";
    public static String LOGINPAGE_URL ="https://www.facebook.com/";
    public static int LINKSCOUNT = 67;
    public static int FOOTERLINKSCOUNT = 41;
    public static String SELECTEDROODOWN = "Germany";
    public static int ROWSCOUNTA = 533;
    public static int ROWSCOUNTALL = 1415;
    public static String FROM = "BENGALURU INTERNATION AIRPORT";
    public static int TIMEOUT = 1000;
    public static String SELECTEDDATE = "28/04/2022";
    public static int ALLLINKS = 13;

    /*Test URLS and locators*/
    public static String HANDLETABPOPURL = "https://www.hdfc.com/";
    public static String FRAMEID = "iframeResult";
    public static String FIRSTURL = "https://www.google.cz/";
    public static String SECONDURL = "https://gmail.com";
    public static String EXPURL = "https://www.way2automation.com/";
    public static int CNTFRAMES = 3;
    public static String TITLESSL = "expired.badssl.com";
    public static String LOCATORFORRES = "//div[@class='ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se']";
    public static String FRAME = "//iframe[@class='demo-frame']";
    public static String URLEXP ="http://deluxe-menu.com/installation-info.html";
    public static String GMAILSEARCHBOXID = "identifierId";
    public static String VALIDATIONMSGREDIFF = "Please enter a valid user name";
    public static String XPATHCOVIDINDIA = "//*[@id='root']/div/div[3]/div[1]/div[4]/div[2]/div/div[9]/div[1]/div[1]";
    public static String COVIDH5XPATH = "//*[@id=\"root\"]/div/div[3]/div[2]/div[2]/div[3]/div[6]/div/h5[2]";

}
